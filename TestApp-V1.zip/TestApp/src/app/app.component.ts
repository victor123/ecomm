import { Component,OnInit} from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  public utc = new Date().toJSON().slice(0,10).replace(/-/g,'/');
  public todayDate:any = new Date;
 public location:string ='Blue Cinema';
 public formValue:any;

 myForm:FormGroup;
  constructor(private fb: FormBuilder) {}

  onSubmit(form) {
    this.formValue = form
 console.log(form)
  }

ngOnInit() {
  this.myForm = this.fb.group({
    userName: ['', [Validators.required,Validators.minLength(3),Validators.maxLength(12)]],
    creaditNumber: ['', [Validators.required,Validators.maxLength(20)]],
    ExDate: ['', Validators.required]
})
}

}
